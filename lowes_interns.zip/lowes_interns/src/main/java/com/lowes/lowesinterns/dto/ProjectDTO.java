package com.lowes.lowesinterns.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ProjectDTO {
    private Integer projectId;

    @NotBlank(message = "projectName cannot be blank")
    private String projectName;

    @NotNull(message = "ideaOwner cannot be null")
    private Integer ideaOwner;

    @NotNull(message = "releaseDate cannot be null")
    private LocalDate releaseDate;

    @Valid
    @NotNull(message = "mentor details cannot be null")
    private MentorDTO mentorDTO;
}
