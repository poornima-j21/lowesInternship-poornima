package com.lowes.lowesinterns.repository;

import com.lowes.lowesinterns.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepository extends JpaRepository<Project, Integer> {
}
