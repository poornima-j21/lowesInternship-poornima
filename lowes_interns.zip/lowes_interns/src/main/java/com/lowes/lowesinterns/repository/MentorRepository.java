package com.lowes.lowesinterns.repository;

import com.lowes.lowesinterns.entity.Mentor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface MentorRepository extends JpaRepository<Mentor, Integer> {
    List<Mentor> findByNumberOfProjectsMentored(Integer numberOfProjectsMentored);
}
