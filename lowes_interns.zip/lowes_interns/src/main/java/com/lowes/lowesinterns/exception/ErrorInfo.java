package com.lowes.lowesinterns.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ErrorInfo {
    private LocalDateTime timestamp;
    private String message;
    private String details;
}
