package com.lowes.lowesinterns.service;

import com.lowes.lowesinterns.dto.MentorDTO;
import com.lowes.lowesinterns.dto.ProjectDTO;
import com.lowes.lowesinterns.entity.Mentor;
import com.lowes.lowesinterns.entity.Project;
import com.lowes.lowesinterns.exception.LowesInternException;
import com.lowes.lowesinterns.repository.MentorRepository;
import com.lowes.lowesinterns.repository.ProjectRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ProjectAllocationServiceImpl {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private MentorRepository mentorRepository;


    public Integer allocateProject(ProjectDTO projectDTO) throws LowesInternException {
        Mentor mentor = mentorRepository.findById(projectDTO.getMentorDTO().getMentorId())
                .orElseThrow(() ->
                        new LowesInternException("Service.MENTOR_NOT_FOUND"));
        if (mentor.getNumberOfProjectsMentored() >= 3) {
            throw new LowesInternException(
                    "Service.CANNOT_ALLOCATE_PROJECT");
        }

        Project project = new Project();
        project.setProjectName(projectDTO.getProjectName());
        project.setIdeaOwner(projectDTO.getIdeaOwner());
        project.setReleaseDate(projectDTO.getReleaseDate());
        project.setMentor(mentor);
        mentor.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored() + 1);
        Project savedProject = projectRepository.save(project);
        return savedProject.getProjectId();

    }

    public List<MentorDTO> getMentors(Integer numberOfProjectsMentored) throws LowesInternException {
        List<Mentor> mentors = mentorRepository.findByNumberOfProjectsMentored(numberOfProjectsMentored);
        if (mentors.isEmpty()) {
            throw new LowesInternException(
                    "Service.MENTOR_NOT_FOUND");
        }

        List<MentorDTO> mentorDTOs = new ArrayList<>();

        for (Mentor mentor : mentors) {
            MentorDTO dto = new MentorDTO();
            dto.setMentorId(mentor.getMentorId());
            dto.setMentorName(mentor.getMentorName());
            dto.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored());
            mentorDTOs.add(dto);
        }

        return mentorDTOs;
    }


    public void updateProjectMentor(Integer projectId, Integer mentorId) throws LowesInternException {

        Mentor mentor = mentorRepository.findById(mentorId)
                .orElseThrow(() ->
                        new LowesInternException("Service.MENTOR_NOT_FOUND"));


        if (mentor.getNumberOfProjectsMentored() >= 3) {
            throw new LowesInternException(
                    "Service.CANNOT_ALLOCATE_PROJECT");
        }

        Project project = projectRepository.findById(projectId)
                .orElseThrow(() ->
                        new LowesInternException("Service.PROJECT_NOT_FOUND"));
        Mentor oldMentor = project.getMentor();

        if (oldMentor != null) {
            oldMentor.setNumberOfProjectsMentored(oldMentor.getNumberOfProjectsMentored() - 1);
        }
        project.setMentor(mentor);
        mentor.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored() + 1);
        projectRepository.save(project);
    }


    public void deleteProject(Integer projectId) throws LowesInternException {

        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new LowesInternException("Service.PROJECT_NOT_FOUND"));

        Mentor mentor = project.getMentor();

        if (mentor != null) {
            mentor.setNumberOfProjectsMentored(
                    mentor.getNumberOfProjectsMentored() - 1);
            project.setMentor(null);
        }
        projectRepository.delete(project);
    }

}

