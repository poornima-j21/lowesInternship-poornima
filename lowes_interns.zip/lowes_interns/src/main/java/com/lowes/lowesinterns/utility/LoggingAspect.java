package com.lowes.lowesinterns.utility;

import com.lowes.lowesinterns.exception.LowesInternException;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;


@Aspect
@Component
public class LoggingAspect {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class);

    @AfterThrowing(
            pointcut = "execution(* com.lowes.lowesinterns.service.ProjectAllocationServiceImpl.*(..))",
            throwing = "exception")
    public void logServiceException(LowesInternException exception) {
        System.out.println("Logging called");
        LOGGER.error(exception.getMessage(), exception);
    }
}