package com.lowes.lowesinterns.exception;

public class LowesInternException extends Exception {
    public LowesInternException(String message) {
        super(message);
    }


}
