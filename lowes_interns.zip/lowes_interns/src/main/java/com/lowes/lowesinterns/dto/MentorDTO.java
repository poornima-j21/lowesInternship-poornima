package com.lowes.lowesinterns.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.validation.constraints.NotNull;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MentorDTO {
    @NotNull(message = "mentorId cannot be null")
    private Integer mentorId;
    private String mentorName;
    private Integer numberOfProjectsMentored;
}
