package com.lowes.lowesinterns.controller;


import java.util.List;

import com.lowes.lowesinterns.service.ProjectAllocationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;

import com.lowes.lowesinterns.dto.MentorDTO;
import com.lowes.lowesinterns.dto.ProjectDTO;
import com.lowes.lowesinterns.exception.LowesInternException;


@RestController
@RequestMapping("/lowesinterns")

public class ProjectAllocationController {

    @Autowired
    private ProjectAllocationServiceImpl projectService;


    @PostMapping("/project")
    public ResponseEntity<String> allocateProject(@Valid @RequestBody ProjectDTO project)
            throws LowesInternException {
        Integer projectId = projectService.allocateProject(project);
        return new ResponseEntity<>("Project allocated successfully : " + projectId,
                HttpStatus.CREATED);
    }

    @GetMapping("/mentor/{numberOfProjectsMentored}")
    public ResponseEntity<List<MentorDTO>> getMentors(
            @PathVariable Integer numberOfProjectsMentored)
            throws LowesInternException {

        List<MentorDTO> mentors = projectService.getMentors(numberOfProjectsMentored);
        return new ResponseEntity<>(mentors, HttpStatus.OK);
    }

    @PutMapping("/project/{projectId}/{mentorId}")
    public ResponseEntity<String> updateProjectMentor(@PathVariable Integer projectId,
                                                      @PathVariable @Pattern(regexp = "\\d{4}",
                                                              message = "{mentor.id.format}")
                                                      String mentorId) throws LowesInternException {

        projectService.updateProjectMentor(projectId, Integer.parseInt(mentorId));
        return new ResponseEntity<>("Project mentor updated successfully",
                HttpStatus.OK);
    }

    @DeleteMapping("/project/{projectId}")
    public ResponseEntity<String> deleteProject(@PathVariable Integer projectId) throws LowesInternException {
        projectService.deleteProject(projectId);
        return new ResponseEntity<>("Project deleted successfully", HttpStatus.OK);
    }

}