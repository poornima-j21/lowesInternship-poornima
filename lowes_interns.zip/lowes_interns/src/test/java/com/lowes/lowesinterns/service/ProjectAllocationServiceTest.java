package com.lowes.lowesinterns.service;

import com.lowes.lowesinterns.dto.MentorDTO;
import com.lowes.lowesinterns.dto.ProjectDTO;

import com.lowes.lowesinterns.entity.Mentor;
import com.lowes.lowesinterns.entity.Project;
import com.lowes.lowesinterns.exception.LowesInternException;
import com.lowes.lowesinterns.repository.MentorRepository;
import com.lowes.lowesinterns.repository.ProjectRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class ProjectAllocationServiceTest {

    @InjectMocks
    private ProjectAllocationServiceImpl projectService;

    @Mock
    private MentorRepository mentorRepository;

    @Mock
    private ProjectRepository projectRepository;

    @Test
    void allocateProjectTest() throws LowesInternException {

        Mentor mentor = new Mentor();
        mentor.setMentorId(1234);
        mentor.setMentorName("Poornima");
        mentor.setNumberOfProjectsMentored(1);

        MentorDTO mentorDTO = new MentorDTO();
        mentorDTO.setMentorId(1234);

        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setProjectName("Spring Project");
        projectDTO.setIdeaOwner(1);
        projectDTO.setReleaseDate(LocalDate.now());
        projectDTO.setMentorDTO(mentorDTO);

        Project savedProject = new Project();
        savedProject.setProjectId(101);
        savedProject.setProjectName("Spring Project");

        when(mentorRepository.findById(1234)).thenReturn(Optional.of(mentor));

        when(projectRepository.save(any(Project.class))).thenReturn(savedProject);

        Integer projectId = projectService.allocateProject(projectDTO);

        assertNotNull(projectId);
        assertEquals(Integer.valueOf(101), projectId);

        assertEquals(2, mentor.getNumberOfProjectsMentored());

        verify(mentorRepository, times(1)).findById(1234);

        verify(projectRepository, times(1)).save(any(Project.class));
    }


    @Test
    void allocateProjectMentorNotFoundTest() {


        MentorDTO mentorDTO = new MentorDTO();
        mentorDTO.setMentorId(1234);

        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setProjectName("Spring Project");
        projectDTO.setIdeaOwner(1);
        projectDTO.setReleaseDate(LocalDate.now());
        projectDTO.setMentorDTO(mentorDTO);

        when(mentorRepository.findById(1234)).thenReturn(Optional.empty());


        LowesInternException exception = assertThrows(
                LowesInternException.class,
                () -> projectService.allocateProject(projectDTO)
        );
        assertEquals(
                "Service.MENTOR_NOT_FOUND",
                exception.getMessage());
        verify(mentorRepository).findById(1234);

    }


    @Test
    void getMentorsTest() throws LowesInternException {


        Mentor mentor = new Mentor();
        mentor.setMentorId(1234);
        mentor.setMentorName("Poornima");
        mentor.setNumberOfProjectsMentored(2);

        when(mentorRepository.findByNumberOfProjectsMentored(2)).thenReturn(List.of(mentor));

        List<MentorDTO> result = projectService.getMentors(2);

        assertEquals(1, result.size());
        assertEquals(1234, result.get(0).getMentorId());
        assertEquals("Poornima", result.get(0).getMentorName());
        assertEquals(2,
                result.get(0).getNumberOfProjectsMentored());

        verify(mentorRepository).findByNumberOfProjectsMentored(2);

    }


    @Test
    void getMentorsNotFoundTest() {


        when(mentorRepository.findByNumberOfProjectsMentored(2))
                .thenReturn(Collections.emptyList());

        LowesInternException exception = assertThrows(
                LowesInternException.class,
                () -> projectService.getMentors(2));

        assertEquals("Service.MENTOR_NOT_FOUND",
                exception.getMessage());
        verify(mentorRepository).findByNumberOfProjectsMentored(2);

    }


    @Test
    void updateProjectMentorTest() throws LowesInternException {

        Mentor oldMentor = new Mentor();
        oldMentor.setMentorId(1111);
        oldMentor.setNumberOfProjectsMentored(2);

        Mentor newMentor = new Mentor();
        newMentor.setMentorId(1234);
        newMentor.setNumberOfProjectsMentored(1);

        Project project = new Project();
        project.setProjectId(101);
        project.setMentor(oldMentor);

        when(mentorRepository.findById(1234)).thenReturn(Optional.of(newMentor));

        when(projectRepository.findById(101)).thenReturn(Optional.of(project));

        projectService.updateProjectMentor(101, 1234);

        assertEquals(newMentor, project.getMentor());
        assertEquals(1, oldMentor.getNumberOfProjectsMentored());
        assertEquals(2, newMentor.getNumberOfProjectsMentored());

        verify(projectRepository).save(project);

    }


    @Test
    void deleteProjectTest() throws LowesInternException {

        Mentor mentor = new Mentor();
        mentor.setMentorId(1234);
        mentor.setNumberOfProjectsMentored(2);

        Project project = new Project();
        project.setProjectId(101);
        project.setMentor(mentor);

        when(projectRepository.findById(101)).thenReturn(Optional.of(project));

        doNothing().when(projectRepository).delete(project);

        projectService.deleteProject(101);

        assertEquals(1, mentor.getNumberOfProjectsMentored());

        assertNull(project.getMentor());

        verify(projectRepository).findById(101);

        verify(projectRepository).delete(project);

    }

}








