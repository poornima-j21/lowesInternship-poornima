package com.lowes.lowesinterns.repository;

import com.lowes.lowesinterns.entity.Mentor;
import com.lowes.lowesinterns.entity.Project;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import java.time.LocalDate;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ProjectAllocationRepositoryTest {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private MentorRepository mentorRepository;

    @Test
    void allocateProjectTest() {

        Mentor mentor = new Mentor();
        mentor.setMentorName("Poornima");
        mentor.setNumberOfProjectsMentored(1);
        Mentor savedMentor = mentorRepository.save(mentor);

        Project project = new Project();
        project.setProjectName("Spring Project");
        project.setIdeaOwner(1);
        project.setReleaseDate(LocalDate.now());
        project.setMentor(savedMentor);
        Project savedProject = projectRepository.save(project);

        assertNotNull(savedProject);
        assertNotNull(savedProject.getProjectId());
        assertEquals("Spring Project", savedProject.getProjectName());
        assertEquals("Poornima", savedProject.getMentor().getMentorName());
    }

    @Test
    void findProjectByIdTest() {

        Project project = new Project();
        project.setProjectName("SpringMvc Project");
        project.setIdeaOwner(2);
        project.setReleaseDate(LocalDate.now());

        Project savedProject = projectRepository.save(project);

        Optional<Project> result = projectRepository.findById(savedProject.getProjectId());

        assertTrue(result.isPresent());
        assertEquals("SpringMvc Project", result.get().getProjectName());
    }


    @Test
    void updateProjectTest() {

        Project project = new Project();
        project.setProjectName("Old Project");
        project.setIdeaOwner(3);
        project.setReleaseDate(LocalDate.now());

        Project savedProject = projectRepository.save(project);

        savedProject.setProjectName("Updated Project");

        Project updatedProject = projectRepository.save(savedProject);

        assertEquals("Updated Project", updatedProject.getProjectName());
    }

    @Test
    void deleteProjectTest() {

        Project project = new Project();
        project.setProjectName("Delete Project");
        project.setIdeaOwner(4);
        project.setReleaseDate(LocalDate.now());

        Project savedProject = projectRepository.save(project);
        Integer projectId = savedProject.getProjectId();
        projectRepository.delete(savedProject);
        Optional<Project> deletedProject = projectRepository.findById(projectId);
        assertFalse(deletedProject.isPresent());
    }
}
