package com.lowes.lowesinterns.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.lowesinterns.dto.MentorDTO;
import com.lowes.lowesinterns.dto.ProjectDTO;

import com.lowes.lowesinterns.service.ProjectAllocationServiceImpl;
import org.springframework.http.MediaType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;


import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.http.RequestEntity.post;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;

@WebMvcTest(ProjectAllocationController.class)
class ProjectAllocationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ProjectAllocationServiceImpl projectAllocationService;

    private final ObjectMapper objectMapper = new ObjectMapper();


   /* @Test
    void allocateProjectTest() throws Exception {

        ProjectDTO projectDTO = new ProjectDTO();

        projectDTO.setProjectName("AI Project");
        projectDTO.setIdeaOwner(1);
        projectDTO.setReleaseDate(LocalDate.of(2026, 7, 18));

        MentorDTO mentorDTO = new MentorDTO();
        mentorDTO.setMentorId(1234);

        projectDTO.setMentorDTO(mentorDTO);


        when(projectAllocationService.allocateProject(any(ProjectDTO.class)))
                .thenReturn(101);


        mockMvc.perform(post("/project")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(projectDTO)))
                .andExpect(status().isCreated())
                .andExpect(content()
                        .string("Project allocated successfully : 101"));


        verify(projectAllocationService)
                .allocateProject(any(ProjectDTO.class));

    }*/

    @Test
    void getMentorsTest() throws Exception {

        MentorDTO mentorDTO = new MentorDTO();

        mentorDTO.setMentorId(1234);
        mentorDTO.setMentorName("John");
        mentorDTO.setNumberOfProjectsMentored(2);


        when(projectAllocationService.getMentors(2))
                .thenReturn(List.of(mentorDTO));


        mockMvc.perform(get("/lowesinterns/projects/mentor/2")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].mentorId").value(1234))
                .andExpect(jsonPath("$[0].mentorName").value("Poornima"))
                .andExpect(jsonPath("$[0].numberOfProjectsMentored").value(2));


        verify(projectAllocationService).getMentors(2);
    }


    @Test
    void updateProjectMentorTest() throws Exception {


        doNothing()
                .when(projectAllocationService)
                .updateProjectMentor(101, 1234);


        mockMvc.perform(put("/project/101/1234")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) content().string("Project mentor updated successfully"));


        verify(projectAllocationService).updateProjectMentor(101, 1234);

    }



    @Test
    void deleteProjectTest() throws Exception {

        doNothing().when(projectAllocationService)
                .deleteProject(101);


        mockMvc.perform(delete("/project/101")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) content().string("Project deleted successfully"));


        verify(projectAllocationService).deleteProject(101);

    }
}